import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  url = "http://localhost:9090/rest/utente/"

  isAdmin = false;
  isLogged = false;

  constructor(private http : HttpClient) { }

  isAuthenticated(): boolean {
    return this.isAdmin;
  }
  isRoleAdmin(): boolean {
    return this.isAdmin;
  }

  setAuthenticated(){
    return this.isLogged = true;
  }

  setAdmin(){
    return this.isAdmin = true;
  }

  setLoggedOut(){
    return this.isLogged = false;
  }

  setUser(){
    this.isAdmin = false;
  }

  singin(username: string, password: string){
    return this.http.get(this.url + "/singin?user="+username + "&pwd=" + password)
  }

  register(body: any){
  return this.http.post(this.url + "/create", body)
  }

}
