import { Component, NgModule } from '@angular/core';
import { NgForm, NgModel } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  resp: any;
  constructor(private router: Router, private auth : AuthService){}


  onSubmit(form: NgForm){
    this.auth.singin(form.value.username, form.value.password)
    .subscribe(data =>{
      console.log(data);
      this.resp = data;
      if(this.resp.rc){
        this.auth.setAuthenticated();
        if(this.resp.dati.role == 'ADMIN')
          this.auth.setAdmin();
        else{
            this.auth.setUser();
          }
        this.router.navigate(['/homepage']);
      }
    })
  }

}
