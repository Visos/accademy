import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './componet/login/login.component';
import { RegisterComponent } from './componet/register/register.component';
import { Pagina1Component } from './componet/pagina1/pagina1.component';
import { Pagina2Component } from './componet/pagina2/pagina2.component';
import { Pagina3Component } from './componet/pagina3/pagina3.component';
import { DashboardComponent } from './componet/dashboard/dashboard.component';
import { authGuard } from './auth/auth.guard';
import { NotFoundComponent } from './component/not-found/not-found.component';

const routes: Routes = [
  {path:"", pathMatch: 'full', redirectTo: "/login"},
{ path : "login", component: LoginComponent },
{ path : "register", component: RegisterComponent},


{path : "dashboard", component: DashboardComponent, canActivate:[authGuard], children: [
  { path: "", redirectTo: "pagina1", pathMatch : 'full' },
  { path : "pagina1", component: Pagina1Component},
  { path : "pagina2", component: Pagina2Component},
  { path : "pagina3", component: Pagina3Component}
]},

{path: "404", component: NotFoundComponent},
{path: "**", redirectTo: "404"  }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
